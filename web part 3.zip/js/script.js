// --- 0. פונקציות עזר לתצוגת תאריכים ---
function formatDate(dateStr) {
    if (!dateStr) return '--';
    var s = String(dateStr).split('T')[0];
    var parts = s.split('-');
    if (parts.length !== 3) return dateStr;
    return parts[2] + '/' + parts[1] + '/' + parts[0];
}

function formatDateTime(dateStr) {
    if (!dateStr) return '--';
    // handles "2026-06-30 21:00:00", "2026-06-30T21:00", "2026-06-30T21:00:00", "2026-06-30"
    var m = String(dateStr).trim().match(/^(\d{4})-(\d{2})-(\d{2})(?:[T\s](\d{2}):(\d{2}))?/);
    if (!m) return String(dateStr);
    var result = m[3] + '/' + m[2] + '/' + m[1];
    if (m[4] && m[5]) result += ', ' + m[4] + ':' + m[5];
    return result;
}

// --- 1. נתונים ומערכות ---
// currentUser נשמר ב-localStorage לשמירת הסשן בין דפים
let currentUser = (function () {
    try {
        const stored = JSON.parse(localStorage.getItem('currentUser'));
        // ולידציה: חייב להיות אובייקט עם email ו-name
        if (stored && stored.email && stored.name) return stored;
        localStorage.removeItem('currentUser'); // נתונים ישנים / שגויים
        return null;
    } catch (e) {
        localStorage.removeItem('currentUser');
        return null;
    }
}());
let currentEvent = null;        // האירוע הנצפה כרגע (מגיע מהשרת)
let currentActiveEventId = null;

// פונקציית עזר לשליחת בקשות fetch לשרת
function apiRequest(method, url, body) {
    const options = {
        method: method,
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) {
        options.body = JSON.stringify(body);
    }
    return fetch(url, options).then(function (res) {
        return res.text().then(function (text) {
            let data;
            try { data = JSON.parse(text); } catch (e) { data = text; }
            if (!res.ok) {
                throw new Error(typeof data === 'string' ? data : (data.error || 'שגיאה'));
            }
            return data;
        });
    });
}

// --- 2. האזנה לטעינת הדף (EventListener 1) ---
document.addEventListener('DOMContentLoaded', function () {
    updateNavbar();
    const path = window.location.pathname;

    if (path.includes('dashboard.html')) {
        if (!currentUser) { window.location.href = 'auth.html'; return; }
        renderDashboard();
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('action') === 'create') {
            showDashboardSub('create-event-section');
        }
    }

    if (path.includes('profile.html')) {
        if (!currentUser) { window.location.href = 'auth.html'; return; }
        renderProfile();
    }

    // ניהול כפתורי הפעולה (דף הבית ודף אודות)
    const ctaButtons = [document.getElementById('heroCTA'), document.getElementById('aboutCTA')];
    ctaButtons.forEach(function (btn) {
        if (btn) {
            if (currentUser) {
                btn.innerText = 'צור אירוע חדש';
                btn.href = 'dashboard.html?action=create';
            } else {
                btn.innerText = 'התחילו עכשיו';
                btn.href = 'auth.html';
            }
        }
    });

    // הגבלת תאריך ושעה עתידיים (datetime-local דורש פורמט YYYY-MM-DDTHH:MM)
    const dateInput = document.getElementById('eventDate');
    if (dateInput) {
        var now = new Date();
        var offset = now.getTimezoneOffset() * 60000;
        dateInput.min = new Date(now - offset).toISOString().slice(0, 16);
    }

    setupFormListeners();
});

function updateNavbar() {
    const nav = document.getElementById('main-nav');
    if (!nav) return;
    const links = [`<li class="nav-item"><a class="nav-link" href="index.html">בית</a></li>`];
    links.push(`<li class="nav-item"><a class="nav-link" href="about.html">אודות</a></li>`);

    if (currentUser) {
        links.push(`<li class="nav-item"><a class="nav-link" href="dashboard.html">האירועים שלי</a></li>`);
        links.push(`<li class="nav-item"><a class="nav-link" href="profile.html">פרופיל</a></li>`);
        links.push(`<li class="nav-item"><a class="nav-link text-danger fw-bold" href="#" onclick="logout()">התנתק</a></li>`);
    } else {
        links.push(`<li class="nav-item"><a class="nav-link fw-bold text-primary" href="auth.html">התחברות</a></li>`);
    }
    nav.innerHTML = links.join('');

    // תפריט המבורגר למובייל
    const headerContainer = document.querySelector('header .container');
    if (headerContainer && !document.getElementById('mobileMenuBtn')) {
        const mobileBtn = document.createElement('button');
        mobileBtn.id = 'mobileMenuBtn';
        mobileBtn.className = 'mobile-menu-btn d-md-none';
        mobileBtn.innerHTML = '☰';
        headerContainer.insertBefore(mobileBtn, headerContainer.querySelector('nav'));
        mobileBtn.addEventListener('click', function () {
            nav.classList.toggle('show-mobile');
        });
    }
}

// --- 3. ולידציות וטפסים (EventListener 2) ---
function setupFormListeners() {
    const signupForm = document.getElementById('signupForm');
    if (signupForm) signupForm.addEventListener('submit', handleSignup);

    const loginForm = document.getElementById('loginForm');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);

    const eventForm = document.getElementById('eventForm');
    if (eventForm) eventForm.addEventListener('submit', handleCreateEvent);

    const editProfileForm = document.getElementById('editProfileForm');
    if (editProfileForm) editProfileForm.addEventListener('submit', handleEditProfile);
}

function handleSignup(e) {
    e.preventDefault();
    const name = document.getElementById('regName').value;
    const email = document.getElementById('regEmail').value;
    const phone = document.getElementById('regPhone').value;
    const password = document.getElementById('regPass').value;

    // ולידציה בצד הלקוח
    if (name.trim().length < 2) return alert("שם חייב להכיל לפחות 2 תווים");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return alert("כתובת אימייל לא תקינה");
    if (!/^05\d{8}$/.test(phone)) return alert("טלפון חייב להיות 10 ספרות ולהתחיל ב-05");
    if (password.length < 8) return alert("סיסמה חייבת להיות לפחות 8 תווים");

    // שליחה לשרת - POST /api/auth/signup
    apiRequest('POST', '/api/auth/signup', { name, email, phone, password })
        .then(function (user) {
            currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            window.location.href = 'dashboard.html';
        })
        .catch(function (err) { alert(err.message); });
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('logEmail').value;
    const password = document.getElementById('logPass').value;

    // שליחה לשרת - POST /api/auth/login
    apiRequest('POST', '/api/auth/login', { email, password })
        .then(function (user) {
            currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            window.location.href = 'dashboard.html';
        })
        .catch(function (err) { alert(err.message); });
}

function handleCreateEvent(e) {
    e.preventDefault();
    const name = document.getElementById('eventName').value;
    const description = document.getElementById('eventDesc').value;
    const event_date = document.getElementById('eventDate').value;
    const location = document.getElementById('eventLocation').value;
    const invites = document.getElementById('invites').value;

    // שליחה לשרת - POST /api/events
    apiRequest('POST', '/api/events', {
        name,
        description,
        event_date,
        location,
        creator_email: currentUser.email,
        invites
    })
        .then(function () {
            window.location.replace('dashboard.html');
        })
        .catch(function (err) { alert(err.message); });
}

// --- 4. לוגיקת דשבורד ---
function renderDashboard() {
    const list = document.getElementById('dynamicEventList');
    if (!list) return;

    list.innerHTML = '<p class="text-center mt-3 text-muted">טוען אירועים...</p>';

    // קבלת האירועים מהשרת - GET /api/events
    apiRequest('GET', '/api/events?userEmail=' + encodeURIComponent(currentUser.email))
        .then(function (events) {
            document.getElementById('eventCount').innerText = events.length;

            if (events.length === 0) {
                list.innerHTML = '<p class="text-center mt-3">אין אירועים.</p>';
                return;
            }

            list.innerHTML = events.map(function (ev) {
                const isManager = ev.creator_email === currentUser.email;
                return `
                <div class="card p-3 mb-3 border-0 shadow-sm d-flex flex-row justify-content-between align-items-center">
                    <div>
                        <h5 class="text-primary mb-1 fw-bold">${ev.name}</h5>
                        <small>📅 ${formatDateTime(ev.event_date)} | 📍 ${ev.location}</small>
                    </div>
                    <div>
                        <button class="btn btn-sm btn-outline-dark mx-1" onclick="viewEventDetails(${ev.id})">${isManager ? 'ניהול וציוות' : 'פרטי אירוע'}</button>
                        ${isManager ? `<button class="btn btn-sm btn-outline-danger" onclick="deleteEvent(${ev.id})">מחק</button>` : ''}
                    </div>
                </div>`;
            }).join('');
        })
        .catch(function (err) {
            list.innerHTML = '<p class="text-center mt-3 text-danger">שגיאה בטעינת האירועים</p>';
            console.log(err);
        });
}

window.viewEventDetails = function (id) {
    currentActiveEventId = id;

    // קבלת פרטי אירוע מהשרת - GET /api/events/:id
    apiRequest('GET', '/api/events/' + id)
        .then(function (ev) {
            currentEvent = ev;

            document.getElementById('dashboard-section').style.display = 'none';
            document.getElementById('event-details-section').style.display = 'block';

            document.getElementById('detName').innerText = ev.name;
            document.getElementById('detMeta').innerText = '📅 ' + formatDateTime(ev.event_date) + ' | 📍 ' + ev.location;
            document.getElementById('detDesc').innerText = ev.description;

            const isManager = ev.creator_email === currentUser.email;
            document.getElementById('inviteArea').style.display = isManager ? 'flex' : 'none';

            const rsvpArea = document.getElementById('rsvpControlsArea');
            if (isManager) {
                rsvpArea.innerHTML = `
                    <div class="d-flex flex-column gap-2 align-items-end">
                        <span class="badge bg-primary fs-6">מנהל/ת</span>
                        <button class="btn btn-sm btn-outline-secondary" onclick="startEventEdit()">✏️ עריכת אירוע</button>
                    </div>`;
            } else {
                const myParticipant = ev.participants.find(function (p) { return p.user_email === currentUser.email; });
                const myStatus = myParticipant ? myParticipant.rsvp_status : 'pending';
                rsvpArea.innerHTML = `
                    <div class="btn-group">
                        <button class="btn btn-sm ${myStatus === 'confirmed' ? 'btn-success' : 'btn-outline-success'}" onclick="setRSVP('confirmed')">מגיע/ה</button>
                        <button class="btn btn-sm ${myStatus === 'declined' ? 'btn-danger' : 'btn-outline-danger'}" onclick="setRSVP('declined')">לא יכול/ה</button>
                    </div>`;
            }

            const controls = document.getElementById('taskManagerControls');
            if (isManager) {
                let options = `<option value="">-- פנוי --</option>` + ev.participants.map(function (p) {
                    return `<option value="${p.user_email}">${p.name || p.user_email}</option>`;
                }).join('');
                controls.innerHTML = `<div class="input-group input-group-sm mb-2"><input type="text" id="taskInput" class="form-control" placeholder="משימה..."><select id="personSelect" class="form-select">${options}</select><button class="btn btn-dark" onclick="addTask()">צור</button></div>`;
            } else {
                controls.innerHTML = `<p class="small text-muted mb-0">בחרו משימה פנויה מהרשימה</p>`;
            }

            renderGuestList(ev);
            renderTasks(ev);
            renderComments(ev);
        })
        .catch(function (err) {
            alert('שגיאה בטעינת האירוע: ' + err.message);
        });
};

window.startEventEdit = function () {
    if (!currentEvent) return;
    // Pre-fill form with current values
    document.getElementById('editEvName').value = currentEvent.name;
    document.getElementById('editEvDesc').value = currentEvent.description || '';
    document.getElementById('editEvLocation').value = currentEvent.location || '';
    // Convert stored "YYYY-MM-DD HH:MM:SS" back to datetime-local format "YYYY-MM-DDTHH:MM"
    var dt = String(currentEvent.event_date).replace(' ', 'T').substring(0, 16);
    document.getElementById('editEvDate').value = dt;
    document.getElementById('eventDisplayView').style.display = 'none';
    document.getElementById('eventEditView').style.display = 'block';
};

window.cancelEventEdit = function () {
    document.getElementById('eventEditView').style.display = 'none';
    document.getElementById('eventDisplayView').style.display = 'block';
};

window.saveEventEdit = function () {
    var name = document.getElementById('editEvName').value;
    var description = document.getElementById('editEvDesc').value;
    var event_date = document.getElementById('editEvDate').value;
    var location = document.getElementById('editEvLocation').value;

    if (!name || name.trim().length < 2) { alert('שם האירוע חייב להכיל לפחות 2 תווים'); return; }
    if (!event_date) { alert('נא לציין תאריך ושעה'); return; }

    apiRequest('PUT', '/api/events/' + currentActiveEventId, {
        name: name,
        description: description,
        event_date: event_date,
        location: location,
        requesterEmail: currentUser.email
    })
        .then(function () {
            cancelEventEdit();
            viewEventDetails(currentActiveEventId);
        })
        .catch(function (err) { alert(err.message); });
};

window.addTask = function () {
    const name = document.getElementById('taskInput').value;
    const assigned_email = document.getElementById('personSelect').value;
    if (!name) return;

    // יצירת משימה - POST /api/events/:id/tasks
    apiRequest('POST', '/api/events/' + currentActiveEventId + '/tasks', {
        name,
        assigned_email: assigned_email || null,
        requesterEmail: currentUser.email
    })
        .then(function () {
            document.getElementById('taskInput').value = '';
            viewEventDetails(currentActiveEventId);
        })
        .catch(function (err) { alert(err.message); });
};

window.changeTaskAssignee = function (taskId, newEmail) {
    // עדכון הקצאת משימה - PUT /api/events/:id/tasks/:taskId
    apiRequest('PUT', '/api/events/' + currentActiveEventId + '/tasks/' + taskId, {
        assigned_email: newEmail || null,
        requesterEmail: currentUser.email
    })
        .then(function () { viewEventDetails(currentActiveEventId); })
        .catch(function (err) { alert(err.message); });
};

window.volunteerTask = function (taskId) {
    // התנדבות למשימה - PUT /api/events/:id/tasks/:taskId
    apiRequest('PUT', '/api/events/' + currentActiveEventId + '/tasks/' + taskId, {
        assigned_email: currentUser.email,
        requesterEmail: currentUser.email
    })
        .then(function () { viewEventDetails(currentActiveEventId); })
        .catch(function (err) { alert(err.message); });
};

window.cancelTask = function (taskId) {
    const task = currentEvent.tasks.find(function (t) { return t.id == taskId; });
    const isManager = currentEvent.creator_email === currentUser.email;

    if (isManager && (!task || !task.assigned_email)) {
        // מנהל מוחק משימה ריקה - DELETE /api/events/:id/tasks/:taskId
        apiRequest('DELETE', '/api/events/' + currentActiveEventId + '/tasks/' + taskId, {
            requesterEmail: currentUser.email
        })
            .then(function () { viewEventDetails(currentActiveEventId); })
            .catch(function (err) { alert(err.message); });
    } else {
        // ביטול הקצאה - PUT /api/events/:id/tasks/:taskId
        apiRequest('PUT', '/api/events/' + currentActiveEventId + '/tasks/' + taskId, {
            assigned_email: null,
            requesterEmail: currentUser.email
        })
            .then(function () { viewEventDetails(currentActiveEventId); })
            .catch(function (err) { alert(err.message); });
    }
};

function renderTasks(ev) {
    const tbody = document.getElementById('taskTableBody');
    const isManager = ev.creator_email === currentUser.email;

    tbody.innerHTML = ev.tasks.map(function (t) {
        const assignee = ev.participants.find(function (p) { return p.user_email === t.assigned_email; });
        let assigneeDisplay = '';

        if (isManager) {
            let options = `<option value="">-- פנוי --</option>` + ev.participants.map(function (p) {
                return `<option value="${p.user_email}" ${t.assigned_email === p.user_email ? 'selected' : ''}>${p.name || p.user_email}</option>`;
            }).join('');
            assigneeDisplay = `<select class="form-select form-select-sm" onchange="changeTaskAssignee(${t.id}, this.value)">${options}</select>`;
        } else {
            assigneeDisplay = t.assigned_email ? (assignee ? assignee.name : t.assigned_email) : 'פנוי';
        }

        let button = '';
        if (!t.assigned_email && !isManager) {
            button = `<button class="btn btn-xs btn-success py-0" onclick="volunteerTask(${t.id})">אני אביא</button>`;
        } else if (isManager || (!t.assigned_by_manager && t.assigned_email === currentUser.email)) {
            button = `<button class="btn btn-xs btn-danger py-0" onclick="cancelTask(${t.id})">בטל</button>`;
        }

        return `<tr><td>${t.name}</td><td>${assigneeDisplay}</td><td>${button}</td></tr>`;
    }).join('');
}

// --- 5. שיח קבוצתי ---
window.postComment = function () {
    const input = document.getElementById('commentInput');
    if (!input.value) return;

    // שליחת הודעה - POST /api/events/:id/comments
    apiRequest('POST', '/api/events/' + currentActiveEventId + '/comments', {
        userEmail: currentUser.email,
        userName: currentUser.name,
        text: input.value
    })
        .then(function () {
            input.value = '';
            viewEventDetails(currentActiveEventId);
        })
        .catch(function (err) { alert(err.message); });
};

function renderComments(ev) {
    const area = document.getElementById('commentsArea');
    if (!area) return;
    area.innerHTML = ev.comments.map(function (c) {
        return `<div class="p-2 mb-1 bg-white rounded shadow-sm small"><strong>${c.user_name}:</strong> ${c.text}<span class="text-muted me-2 float-start" style="font-size:0.75em">${formatDateTime(c.created_at)}</span></div>`;
    }).join('');
    area.scrollTop = area.scrollHeight;
}

// --- 6. פרופיל ---
function renderProfile() {
    if (!currentUser) return;
    const nameEl = document.getElementById('profName');
    const emailEl = document.getElementById('profEmail');
    if (nameEl) nameEl.innerText = currentUser.name;
    if (emailEl) emailEl.innerText = currentUser.email;
    const phoneEl = document.getElementById('profPhone');
    if (phoneEl) phoneEl.innerText = currentUser.phone || '';

    const editName = document.getElementById('editName');
    const editEmail = document.getElementById('editEmail');
    const editPhone = document.getElementById('editPhone');
    const editCurrentEmail = document.getElementById('editCurrentEmail');
    if (editName) editName.value = currentUser.name;
    if (editEmail) editEmail.value = currentUser.email;
    if (editPhone) editPhone.value = currentUser.phone || '';
    if (editCurrentEmail) editCurrentEmail.value = currentUser.email;

    const list = document.getElementById('userHistoryList');
    if (!list) return;

    list.innerHTML = '<li class="mb-2 p-2 bg-light rounded">טוען...</li>';

    // קבלת היסטוריית אירועים מהשרת - GET /api/events
    apiRequest('GET', '/api/events?userEmail=' + encodeURIComponent(currentUser.email))
        .then(function (events) {
            list.innerHTML = events.map(function (e) {
                return `<li class="mb-2 p-2 bg-light rounded shadow-sm">${e.name} (${formatDateTime(e.event_date)})</li>`;
            }).join('') || 'טרם השתתפת באירועים.';
        })
        .catch(function () { list.innerHTML = 'שגיאה בטעינת האירועים.'; });
}

window.toggleEditProfile = function () {
    var wrapper = document.getElementById('editProfileWrapper');
    wrapper.style.display = wrapper.style.display === 'none' ? 'block' : 'none';
};

window.deleteAccount = function () {
    if (!confirm('האם אתה בטוח? פעולה זו תמחק את החשבון שלך לצמיתות ולא ניתן לבטלה.')) return;
    apiRequest('DELETE', '/api/auth/account', { email: currentUser.email })
        .then(function () {
            localStorage.removeItem('currentUser');
            window.location.href = 'index.html';
        })
        .catch(function (err) { alert('שגיאה במחיקת החשבון: ' + err.message); });
};

function handleEditProfile(e) {
    e.preventDefault();
    const name = document.getElementById('editName').value;
    const email = document.getElementById('editEmail').value;
    const phone = document.getElementById('editPhone').value;
    const password = document.getElementById('editPassword').value;
    const passwordConfirm = document.getElementById('editPasswordConfirm').value;
    const msgEl = document.getElementById('editProfileMsg');

    if (name.trim().length < 2) { msgEl.innerHTML = '<div class="alert alert-danger">שם חייב להכיל לפחות 2 תווים</div>'; return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { msgEl.innerHTML = '<div class="alert alert-danger">כתובת אימייל לא תקינה</div>'; return; }
    if (!/^05\d{8}$/.test(phone)) { msgEl.innerHTML = '<div class="alert alert-danger">טלפון חייב להיות 10 ספרות ולהתחיל ב-05</div>'; return; }
    if (password && password.length < 8) { msgEl.innerHTML = '<div class="alert alert-danger">סיסמה חייבת להיות לפחות 8 תווים</div>'; return; }
    if (password !== passwordConfirm) { msgEl.innerHTML = '<div class="alert alert-danger">הסיסמאות אינן תואמות</div>'; return; }

    var body = { currentEmail: currentUser.email, name: name, email: email, phone: phone };
    if (password) body.password = password;

    apiRequest('PUT', '/api/auth/profile', body)
        .then(function (updated) {
            currentUser.name = updated.name;
            currentUser.email = updated.email;
            currentUser.phone = updated.phone;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            document.getElementById('profName').innerText = currentUser.name;
            document.getElementById('profEmail').innerText = currentUser.email;
            document.getElementById('profPhone').innerText = currentUser.phone;
            document.getElementById('editPassword').value = '';
            document.getElementById('editPasswordConfirm').value = '';
            msgEl.innerHTML = '<div class="alert alert-success">הפרופיל עודכן בהצלחה ✓</div>';
        })
        .catch(function (err) {
            msgEl.innerHTML = '<div class="alert alert-danger">' + err.message + '</div>';
        });
}

window.setRSVP = function (status) {
    // עדכון RSVP - PUT /api/events/:id/rsvp
    apiRequest('PUT', '/api/events/' + currentActiveEventId + '/rsvp', {
        userEmail: currentUser.email,
        status: status
    })
        .then(function () { viewEventDetails(currentActiveEventId); })
        .catch(function (err) { alert(err.message); });
};

window.deleteEvent = function (id) {
    if (confirm('מחק אירוע?')) {
        // מחיקת אירוע - DELETE /api/events/:id
        apiRequest('DELETE', '/api/events/' + id, { userEmail: currentUser.email })
            .then(function () { renderDashboard(); })
            .catch(function (err) { alert(err.message); });
    }
};

window.inviteMoreGuests = function () {
    const email = document.getElementById('newGuestEmail').value.trim();
    if (!email) { alert("נא להזין כתובת אימייל"); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { alert("כתובת אימייל לא תקינה"); return; }

    // הזמנת משתתף - POST /api/events/:id/participants
    apiRequest('POST', '/api/events/' + currentActiveEventId + '/participants', {
        userEmail: email,
        requesterEmail: currentUser.email
    })
        .then(function () {
            document.getElementById('newGuestEmail').value = '';
            viewEventDetails(currentActiveEventId);
        })
        .catch(function (err) { alert(err.message); });
};

function renderGuestList(ev) {
    const list = document.getElementById('guestListGroup');
    const isManager = ev.creator_email === currentUser.email;

    list.innerHTML = ev.participants.map(function (p) {
        const name = p.name || p.user_email;
        const isCreator = p.user_email === ev.creator_email;
        let badge = '';

        if (isCreator) {
            badge = '<span class="badge bg-primary">מנהל/ת</span>';
        } else if (isManager) {
            if (p.rsvp_status === 'confirmed') badge = '<span class="badge bg-success">מאשר</span>';
            else if (p.rsvp_status === 'declined') badge = '<span class="badge bg-danger">לא מגיע</span>';
            else badge = '<span class="badge bg-light text-dark border">טרם השיב</span>';
        }

        return `<li class="list-group-item py-2 border-0 guest-list-item"><div>${name}</div>${badge ? `<div class="mt-1">${badge}</div>` : ''}</li>`;
    }).join('');
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
}

// --- פונקציות ניווט ---
function toggleAuth() {
    const l = document.getElementById('loginBox');
    const s = document.getElementById('signupBox');
    if (l.style.display === 'none') {
        l.style.display = 'block';
        s.style.display = 'none';
    } else {
        l.style.display = 'none';
        s.style.display = 'block';
    }
}

function showDashboardSub(id) {
    window.history.replaceState({}, document.title, window.location.pathname);
    ['dashboard-section', 'create-event-section', 'event-details-section'].forEach(function (s) {
        document.getElementById(s).style.display = 'none';
    });
    document.getElementById(id).style.display = 'block';
    if (id === 'dashboard-section') renderDashboard();
}

const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const authRoutes = require("./routes/auth");
const eventRoutes = require("./routes/events");
const taskRoutes = require("./routes/tasks");
const commentRoutes = require("./routes/comments");

const app = express();
const port = 3000;

// =====================
// Middleware
// =====================

// parse requests of content-type: application/json
app.use(bodyParser.json());

// parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static frontend files from the parent folder
app.use(express.static(path.join(__dirname, "..")));

// =====================
// API Routes
// =====================

app.use("/api/auth", authRoutes);
app.use("/api/events", eventRoutes);
app.use("/api/events/:id/tasks", taskRoutes);
app.use("/api/events/:id/comments", commentRoutes);

// Fallback: serve index.html for any unknown route
app.get("*", function (req, res) {
    res.sendFile(path.join(__dirname, "..", "index.html"));
});

// =====================
// Start server
// =====================
app.listen(port, function () {
    console.log("PlanIt server is running on port " + port);
});

const express = require("express");
const router = express.Router();
const sql = require("../db/db.js");

// --- POST /api/auth/signup ---
router.post("/signup", function (req, res) {
    const { name, email, phone, password } = req.body;

    // Server-side validation
    if (!name || name.trim().length < 2) {
        res.status(400).send("שם חייב להכיל לפחות 2 תווים");
        return;
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        res.status(400).send("כתובת אימייל לא תקינה");
        return;
    }
    if (!phone || !/^05\d{8}$/.test(phone)) {
        res.status(400).send("טלפון חייב להיות 10 ספרות ולהתחיל ב-05");
        return;
    }
    if (!password || password.length < 8) {
        res.status(400).send("סיסמה חייבת להיות לפחות 8 תווים");
        return;
    }

    // Check if email already registered
    sql.query("SELECT id FROM users WHERE email = ?", [email], (err, results) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (results.length > 0) {
            res.status(409).send("משתמש עם אימייל זה כבר רשום");
            return;
        }

        // Insert new user
        sql.query(
            "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)",
            [name.trim(), email, phone, password],
            (err, mysqlres) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }
                console.log("new user registered: ", email);
                res.json({ name: name.trim(), email, phone });
            }
        );
    });
});

// --- POST /api/auth/login ---
router.post("/login", function (req, res) {
    const { email, password } = req.body;

    console.log("Login attempt - email:", email, "| password received:", !!password);

    if (!email || !password) {
        console.log("Login failed: missing email or password. body was:", req.body);
        res.status(400).send("נא למלא אימייל וסיסמה");
        return;
    }

    sql.query(
        "SELECT id, name, email, phone, password, active FROM users WHERE email = ?",
        [email],
        (err, results) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send("שגיאת שרת: " + err);
                return;
            }
            if (results.length === 0) {
                res.status(404).send("אינך רשום למערכת, נא הירשם");
                return;
            }
            if (!results[0].active) {
                res.status(403).send("החשבון הזה אינו פעיל");
                return;
            }

            const user = results[0];

            console.log("DB password:", user.password, "| Entered password:", password);
            if (user.password !== password) {
                res.status(401).send("סיסמה שגויה");
                return;
            }

            console.log("user logged in: ", email);
            res.json({ id: user.id, name: user.name, email: user.email, phone: user.phone });
        }
    );
});

// --- DELETE /api/auth/account ---
router.delete("/account", function (req, res) {
    const { email } = req.body;

    if (!email) { res.status(400).send("נדרש אימייל"); return; }

    sql.query("UPDATE users SET active = 0 WHERE email = ?", [email], (err, result) => {
        if (err) { console.log("error: ", err); res.status(500).send("שגיאת שרת"); return; }
        if (result.affectedRows === 0) { res.status(404).send("משתמש לא נמצא"); return; }
        console.log("account deactivated: ", email);
        res.send("החשבון הושבת בהצלחה");
    });
});

// --- PUT /api/auth/profile ---
// (also reachable via POST for classic <form action="..." method="POST"> submission,
// since native HTML forms cannot send PUT requests)
router.post("/profile", handleProfileUpdate);
router.put("/profile", handleProfileUpdate);

function handleProfileUpdate(req, res) {
    const { currentEmail, name, email, phone, password } = req.body;

    if (!currentEmail) { res.status(400).send("נדרש אימייל נוכחי"); return; }
    if (!name || name.trim().length < 2) { res.status(400).send("שם חייב להכיל לפחות 2 תווים"); return; }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { res.status(400).send("כתובת אימייל לא תקינה"); return; }
    if (!phone || !/^05\d{8}$/.test(phone)) { res.status(400).send("טלפון חייב להיות 10 ספרות ולהתחיל ב-05"); return; }
    if (password && password.length < 8) { res.status(400).send("סיסמה חייבת להיות לפחות 8 תווים"); return; }

    // Check new email isn't taken by a different user
    sql.query("SELECT id FROM users WHERE email = ? AND email != ?", [email, currentEmail], (err, results) => {
        if (err) { console.log("error: ", err); res.status(500).send("שגיאת שרת"); return; }
        if (results.length > 0) { res.status(409).send("כתובת האימייל כבר קיימת במערכת"); return; }

        var query, params;
        if (password) {
            query = "UPDATE users SET name = ?, email = ?, phone = ?, password = ? WHERE email = ?";
            params = [name.trim(), email, phone, password, currentEmail];
        } else {
            query = "UPDATE users SET name = ?, email = ?, phone = ? WHERE email = ?";
            params = [name.trim(), email, phone, currentEmail];
        }

        sql.query(query, params, (err, result) => {
            if (err) { console.log("error: ", err); res.status(500).send("שגיאת שרת"); return; }
            if (result.affectedRows === 0) { res.status(404).send("משתמש לא נמצא"); return; }
            console.log("profile updated for: ", currentEmail);
            res.json({ name: name.trim(), email, phone });
        });
    });
}

module.exports = router;

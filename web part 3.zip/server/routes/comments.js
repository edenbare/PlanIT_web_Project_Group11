const express = require("express");
const router = express.Router({ mergeParams: true });
const sql = require("../db/db.js");

// --- POST /api/events/:id/comments ---
// Post a new comment on an event
router.post("/", function (req, res) {
    const eventId = req.params.id;
    const { userEmail, userName, text } = req.body;

    // Server-side validation
    if (!userEmail) {
        res.status(400).send("נדרש אימייל משתמש");
        return;
    }
    if (!text || text.trim().length === 0) {
        res.status(400).send("תוכן ההודעה לא יכול להיות ריק");
        return;
    }
    if (text.trim().length > 1000) {
        res.status(400).send("הודעה ארוכה מדי (מקסימום 1000 תווים)");
        return;
    }

    // Verify event exists
    sql.query("SELECT id FROM events WHERE id = ?", [eventId], (err, eventResults) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (eventResults.length === 0) {
            res.status(404).send("אירוע לא נמצא");
            return;
        }

        // Verify commenter is a participant
        sql.query(
            "SELECT id FROM event_participants WHERE event_id = ? AND user_email = ?",
            [eventId, userEmail],
            (err, partResults) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }
                if (partResults.length === 0) {
                    res.status(403).send("רק משתתפים יכולים לפרסם הודעות");
                    return;
                }

                sql.query(
                    "INSERT INTO comments (event_id, user_name, user_email, text) VALUES (?, ?, ?, ?)",
                    [eventId, userName || userEmail, userEmail, text.trim()],
                    (err, mysqlres) => {
                        if (err) {
                            console.log("error: ", err);
                            res.status(500).send("שגיאת שרת: " + err);
                            return;
                        }
                        console.log("comment posted by: ", userEmail);
                        res.json({ message: "ההודעה פורסמה בהצלחה", commentId: mysqlres.insertId });
                    }
                );
            }
        );
    });
});

// --- DELETE /api/events/:id/comments/:commentId ---
// Delete a comment (author only)
router.delete("/:commentId", function (req, res) {
    const eventId = req.params.id;
    const commentId = req.params.commentId;
    const userEmail = req.body.userEmail;

    if (!userEmail) {
        res.status(400).send("נדרש אימייל משתמש");
        return;
    }

    sql.query(
        "SELECT user_email FROM comments WHERE id = ? AND event_id = ?",
        [commentId, eventId],
        (err, results) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send("שגיאת שרת: " + err);
                return;
            }
            if (results.length === 0) {
                res.status(404).send("הודעה לא נמצאה");
                return;
            }
            if (results[0].user_email !== userEmail) {
                res.status(403).send("אינך רשאי למחוק הודעה זו");
                return;
            }

            sql.query("DELETE FROM comments WHERE id = ?", [commentId], (err) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }
                res.send("ההודעה נמחקה בהצלחה");
            });
        }
    );
});

module.exports = router;

const express = require("express");
const router = express.Router({ mergeParams: true });
const sql = require("../db/db.js");

// --- POST /api/events/:id/tasks ---
// Create a new task (event manager only)
router.post("/", function (req, res) {
    const eventId = req.params.id;
    const { name, assigned_email, requesterEmail } = req.body;

    if (!name || name.trim().length === 0) {
        res.status(400).send("שם המשימה לא יכול להיות ריק");
        return;
    }
    if (!requesterEmail) {
        res.status(400).send("נדרש אימייל מבקש");
        return;
    }

    // Verify requester is the event creator
    sql.query("SELECT creator_email FROM events WHERE id = ?", [eventId], (err, results) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (results.length === 0) {
            res.status(404).send("אירוע לא נמצא");
            return;
        }
        if (results[0].creator_email !== requesterEmail) {
            res.status(403).send("רק מנהל האירוע יכול ליצור משימות");
            return;
        }

        const isAssignedByManager = assigned_email ? 1 : 0;

        sql.query(
            "INSERT INTO tasks (event_id, name, assigned_email, assigned_by_manager) VALUES (?, ?, ?, ?)",
            [eventId, name.trim(), assigned_email || null, isAssignedByManager],
            (err, mysqlres) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }
                console.log("task created: ", mysqlres.insertId);
                res.json({ message: "משימה נוצרה בהצלחה", taskId: mysqlres.insertId });
            }
        );
    });
});

// --- PUT /api/events/:id/tasks/:taskId ---
// Update task assignment (manager reassigns, participant volunteers or cancels)
router.put("/:taskId", function (req, res) {
    const eventId = req.params.id;
    const taskId = req.params.taskId;
    const { assigned_email, requesterEmail } = req.body;

    if (!requesterEmail) {
        res.status(400).send("נדרש אימייל מבקש");
        return;
    }

    // Get event creator
    sql.query("SELECT creator_email FROM events WHERE id = ?", [eventId], (err, eventResults) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (eventResults.length === 0) {
            res.status(404).send("אירוע לא נמצא");
            return;
        }

        const isManager = (eventResults[0].creator_email === requesterEmail);

        // Get the task
        sql.query(
            "SELECT * FROM tasks WHERE id = ? AND event_id = ?",
            [taskId, eventId],
            (err, taskResults) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }
                if (taskResults.length === 0) {
                    res.status(404).send("משימה לא נמצאה");
                    return;
                }

                const task = taskResults[0];

                if (isManager) {
                    // Manager can freely reassign
                    const isAssignedByManager = assigned_email ? 1 : 0;
                    sql.query(
                        "UPDATE tasks SET assigned_email = ?, assigned_by_manager = ? WHERE id = ?",
                        [assigned_email || null, isAssignedByManager, taskId],
                        (err) => {
                            if (err) {
                                console.log("error: ", err);
                                res.status(500).send("שגיאת שרת: " + err);
                                return;
                            }
                            res.send("המשימה עודכנה בהצלחה");
                        }
                    );
                } else {
                    // Participant: can only volunteer (take free task) or cancel own self-assigned task
                    if (assigned_email && assigned_email !== requesterEmail) {
                        res.status(403).send("אינך רשאי להקצות משימה לאחר");
                        return;
                    }
                    if (assigned_email) {
                        // Volunteering - task must be free
                        if (task.assigned_email !== null) {
                            res.status(409).send("המשימה כבר תפוסה");
                            return;
                        }
                        sql.query(
                            "UPDATE tasks SET assigned_email = ?, assigned_by_manager = 0 WHERE id = ?",
                            [requesterEmail, taskId],
                            (err) => {
                                if (err) {
                                    console.log("error: ", err);
                                    res.status(500).send("שגיאת שרת: " + err);
                                    return;
                                }
                                res.send("נרשמת למשימה בהצלחה");
                            }
                        );
                    } else {
                        // Cancelling - only if self-assigned (not by manager)
                        if (task.assigned_by_manager) {
                            res.status(403).send("אינך יכול לבטל משימה שהוקצתה על ידי המנהל");
                            return;
                        }
                        if (task.assigned_email !== requesterEmail) {
                            res.status(403).send("אינך יכול לבטל משימה של אחר");
                            return;
                        }
                        sql.query(
                            "UPDATE tasks SET assigned_email = NULL, assigned_by_manager = 0 WHERE id = ?",
                            [taskId],
                            (err) => {
                                if (err) {
                                    console.log("error: ", err);
                                    res.status(500).send("שגיאת שרת: " + err);
                                    return;
                                }
                                res.send("המשימה בוטלה בהצלחה");
                            }
                        );
                    }
                }
            }
        );
    });
});

// --- DELETE /api/events/:id/tasks/:taskId ---
// Delete a task (event manager only)
router.delete("/:taskId", function (req, res) {
    const eventId = req.params.id;
    const taskId = req.params.taskId;
    const requesterEmail = req.body.requesterEmail;

    if (!requesterEmail) {
        res.status(400).send("נדרש אימייל מבקש");
        return;
    }

    sql.query("SELECT creator_email FROM events WHERE id = ?", [eventId], (err, results) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (results.length === 0) {
            res.status(404).send("אירוע לא נמצא");
            return;
        }
        if (results[0].creator_email !== requesterEmail) {
            res.status(403).send("רק מנהל האירוע יכול למחוק משימות");
            return;
        }

        sql.query(
            "DELETE FROM tasks WHERE id = ? AND event_id = ?",
            [taskId, eventId],
            (err, mysqlres) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }
                if (mysqlres.affectedRows === 0) {
                    res.status(404).send("משימה לא נמצאה");
                    return;
                }
                console.log("task deleted: ", taskId);
                res.send("המשימה נמחקה בהצלחה");
            }
        );
    });
});

module.exports = router;

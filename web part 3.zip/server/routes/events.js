const express = require("express");
const router = express.Router();
const sql = require("../db/db.js");

// --- GET /api/events?userEmail=... ---
// Returns all events where the user is a participant
router.get("/", function (req, res) {
    const userEmail = req.query.userEmail;

    if (!userEmail) {
        res.status(400).send("נדרש אימייל משתמש");
        return;
    }

    sql.query(
        `SELECT e.*, ep.rsvp_status AS my_rsvp
         FROM events e
         JOIN event_participants ep ON e.id = ep.event_id
         WHERE ep.user_email = ?
         ORDER BY e.event_date ASC`,
        [userEmail],
        (err, results) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send("שגיאת שרת: " + err);
                return;
            }
            console.log("got events for user: ", userEmail);
            res.send(results);
        }
    );
});

// --- GET /api/events/:id ---
// Returns full details of a single event including participants, tasks, comments
router.get("/:id", function (req, res) {
    const eventId = req.params.id;

    if (isNaN(eventId)) {
        res.status(400).send("מזהה אירוע לא תקין");
        return;
    }

    // Step 1: Get the event
    sql.query("SELECT * FROM events WHERE id = ?", [eventId], (err, eventResults) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (eventResults.length === 0) {
            res.status(404).send("אירוע לא נמצא");
            return;
        }

        const event = eventResults[0];

        // Step 2: Get participants with their names and RSVP status
        sql.query(
            `SELECT ep.user_email, ep.rsvp_status, u.name
             FROM event_participants ep
             LEFT JOIN users u ON ep.user_email = u.email
             WHERE ep.event_id = ?`,
            [eventId],
            (err, participants) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }

                // Step 3: Get tasks
                sql.query(
                    "SELECT * FROM tasks WHERE event_id = ? ORDER BY id ASC",
                    [eventId],
                    (err, tasks) => {
                        if (err) {
                            console.log("error: ", err);
                            res.status(500).send("שגיאת שרת: " + err);
                            return;
                        }

                        // Step 4: Get comments
                        sql.query(
                            "SELECT * FROM comments WHERE event_id = ? ORDER BY created_at ASC",
                            [eventId],
                            (err, comments) => {
                                if (err) {
                                    console.log("error: ", err);
                                    res.status(500).send("שגיאת שרת: " + err);
                                    return;
                                }

                                console.log("got details for event: ", eventId);
                                res.json({ ...event, participants, tasks, comments });
                            }
                        );
                    }
                );
            }
        );
    });
});

// --- POST /api/events ---
// Create a new event
router.post("/", function (req, res) {
    const { name, description, event_date, location, creator_email, invites } = req.body;

    // Server-side validation
    if (!name || name.trim().length < 2) {
        res.status(400).send("שם האירוע חייב להכיל לפחות 2 תווים");
        return;
    }
    if (!event_date) {
        res.status(400).send("נא לציין תאריך לאירוע");
        return;
    }
    if (new Date(event_date) <= new Date()) {
        res.status(400).send("תאריך ושעת האירוע חייבים להיות בעתיד");
        return;
    }
    if (!creator_email) {
        res.status(400).send("נדרש אימייל יוצר האירוע");
        return;
    }

    // Parse invite list
    const inviteList = Array.isArray(invites)
        ? invites
        : (invites ? String(invites).split(",").map(e => e.trim()).filter(e => e) : []);

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    for (const email of inviteList) {
        if (!emailRegex.test(email)) {
            res.status(400).send("כתובת אימייל לא תקינה: " + email);
            return;
        }
    }

    // Normalize datetime-local value ("2026-06-30T21:00") → MySQL format ("2026-06-30 21:00:00")
    var normalizedDate = event_date.replace('T', ' ');
    if ((normalizedDate.match(/:/g) || []).length === 1) normalizedDate += ':00';

    // Insert the event
    sql.query(
        "INSERT INTO events (name, description, event_date, location, creator_email) VALUES (?, ?, ?, ?, ?)",
        [name.trim(), description || "", normalizedDate, location || "לא צוין", creator_email],
        (err, mysqlres) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send("שגיאת שרת: " + err);
                return;
            }

            const eventId = mysqlres.insertId;

            // Add creator as confirmed participant
            sql.query(
                "INSERT INTO event_participants (event_id, user_email, rsvp_status) VALUES (?, ?, 'confirmed')",
                [eventId, creator_email],
                (err) => {
                    if (err) {
                        console.log("error: ", err);
                        res.status(500).send("שגיאת שרת: " + err);
                        return;
                    }

                    // Add remaining invitees (one by one)
                    const otherInvites = inviteList.filter(e => e !== creator_email);
                    let inserted = 0;

                    if (otherInvites.length === 0) {
                        console.log("event created: ", eventId);
                        res.json({ message: "האירוע נוצר בהצלחה", eventId });
                        return;
                    }

                    otherInvites.forEach(email => {
                        sql.query(
                            "INSERT IGNORE INTO event_participants (event_id, user_email, rsvp_status) VALUES (?, ?, 'pending')",
                            [eventId, email],
                            (err) => {
                                if (err) console.log("error adding invite: ", err);
                                inserted++;
                                if (inserted === otherInvites.length) {
                                    console.log("event created: ", eventId);
                                    res.json({ message: "האירוע נוצר בהצלחה", eventId });
                                }
                            }
                        );
                    });
                }
            );
        }
    );
});

// --- PUT /api/events/:id ---
// Edit event details (creator only)
router.put("/:id", function (req, res) {
    const eventId = req.params.id;
    const { name, description, event_date, location, requesterEmail } = req.body;

    if (!requesterEmail) { res.status(400).send("נדרש אימייל מבקש"); return; }
    if (!name || name.trim().length < 2) { res.status(400).send("שם האירוע חייב להכיל לפחות 2 תווים"); return; }
    if (!event_date) { res.status(400).send("נא לציין תאריך לאירוע"); return; }

    var normalizedDate = event_date.replace('T', ' ');
    if ((normalizedDate.match(/:/g) || []).length === 1) normalizedDate += ':00';

    if (new Date(event_date) <= new Date()) { res.status(400).send("תאריך ושעת האירוע חייבים להיות בעתיד"); return; }

    sql.query("SELECT creator_email FROM events WHERE id = ?", [eventId], (err, results) => {
        if (err) { console.log("error: ", err); res.status(500).send("שגיאת שרת"); return; }
        if (results.length === 0) { res.status(404).send("אירוע לא נמצא"); return; }
        if (results[0].creator_email !== requesterEmail) { res.status(403).send("רק יוצר האירוע רשאי לערוך אותו"); return; }

        sql.query(
            "UPDATE events SET name = ?, description = ?, event_date = ?, location = ? WHERE id = ?",
            [name.trim(), description || "", normalizedDate, location || "לא צוין", eventId],
            (err) => {
                if (err) { console.log("error: ", err); res.status(500).send("שגיאת שרת"); return; }
                console.log("event updated: ", eventId);
                res.send("האירוע עודכן בהצלחה");
            }
        );
    });
});

// --- DELETE /api/events/:id ---
// Delete an event (only the creator can delete)
router.delete("/:id", function (req, res) {
    const eventId = req.params.id;
    const userEmail = req.body.userEmail;

    if (isNaN(eventId)) {
        res.status(400).send("מזהה אירוע לא תקין");
        return;
    }
    if (!userEmail) {
        res.status(400).send("נדרש אימייל משתמש");
        return;
    }

    // Verify the requester is the event creator
    sql.query("SELECT creator_email FROM events WHERE id = ?", [eventId], (err, results) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (results.length === 0) {
            res.status(404).send("אירוע לא נמצא");
            return;
        }
        if (results[0].creator_email !== userEmail) {
            res.status(403).send("רק יוצר האירוע רשאי למחוק אותו");
            return;
        }

        sql.query("DELETE FROM events WHERE id = ?", [eventId], (err) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send("שגיאת שרת: " + err);
                return;
            }
            console.log("event deleted: ", eventId);
            res.send("האירוע נמחק בהצלחה");
        });
    });
});

// --- POST /api/events/:id/participants ---
// Invite an additional guest
router.post("/:id/participants", function (req, res) {
    const eventId = req.params.id;
    const { userEmail, requesterEmail } = req.body;

    if (!userEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userEmail)) {
        res.status(400).send("כתובת אימייל לא תקינה");
        return;
    }

    sql.query("SELECT creator_email FROM events WHERE id = ?", [eventId], (err, results) => {
        if (err) {
            console.log("error: ", err);
            res.status(500).send("שגיאת שרת: " + err);
            return;
        }
        if (results.length === 0) {
            res.status(404).send("אירוע לא נמצא");
            return;
        }
        if (results[0].creator_email !== requesterEmail) {
            res.status(403).send("רק יוצר האירוע יכול להזמין משתתפים");
            return;
        }

        sql.query(
            "INSERT IGNORE INTO event_participants (event_id, user_email, rsvp_status) VALUES (?, ?, 'pending')",
            [eventId, userEmail],
            (err) => {
                if (err) {
                    console.log("error: ", err);
                    res.status(500).send("שגיאת שרת: " + err);
                    return;
                }
                console.log("participant added: ", userEmail);
                res.send("המוזמן נוסף בהצלחה");
            }
        );
    });
});

// --- PUT /api/events/:id/rsvp ---
// Update a participant's RSVP status
router.put("/:id/rsvp", function (req, res) {
    const eventId = req.params.id;
    const { userEmail, status } = req.body;

    const validStatuses = ["confirmed", "declined", "pending"];
    if (!validStatuses.includes(status)) {
        res.status(400).send("סטטוס RSVP לא תקין");
        return;
    }
    if (!userEmail) {
        res.status(400).send("נדרש אימייל משתמש");
        return;
    }

    sql.query(
        "UPDATE event_participants SET rsvp_status = ? WHERE event_id = ? AND user_email = ?",
        [status, eventId, userEmail],
        (err, mysqlres) => {
            if (err) {
                console.log("error: ", err);
                res.status(500).send("שגיאת שרת: " + err);
                return;
            }
            if (mysqlres.affectedRows === 0) {
                res.status(404).send("המשתמש אינו משתתף באירוע זה");
                return;
            }
            console.log("rsvp updated for: ", userEmail);
            res.send("סטטוס עודכן בהצלחה");
        }
    );
});

module.exports = router;

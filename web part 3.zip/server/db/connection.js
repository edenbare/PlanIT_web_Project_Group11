const mysql = require('mysql2');

// Create a connection pool for better performance and reliability
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',       // Change to your MySQL username
    password: 'Edenb12072!',       // Change to your MySQL password
    database: 'planit_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Expose promise-based interface for async/await usage
module.exports = pool.promise();

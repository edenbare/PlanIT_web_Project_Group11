-- PlanIt Database Initialization Script
-- Run this file once in MySQL Workbench or via: mysql -u root -p < db/init.sql

CREATE DATABASE IF NOT EXISTS planit_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE planit_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Migration for existing databases (run manually if table already exists):
-- ALTER TABLE users ADD COLUMN active TINYINT(1) NOT NULL DEFAULT 1;
-- ALTER TABLE events MODIFY COLUMN event_date DATETIME NOT NULL;

-- Events table
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    event_date DATETIME NOT NULL,
    location VARCHAR(255) DEFAULT 'לא צוין',
    creator_email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (creator_email) REFERENCES users(email) ON DELETE CASCADE
);

-- Event participants & RSVP status
CREATE TABLE IF NOT EXISTS event_participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    rsvp_status ENUM('pending', 'confirmed', 'declined') DEFAULT 'pending',
    UNIQUE KEY unique_participant (event_id, user_email),
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

-- Tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    assigned_email VARCHAR(255) DEFAULT NULL,
    assigned_by_manager TINYINT(1) DEFAULT 0,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_name VARCHAR(100) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "Edenb12072!",
    DB: "planit_db"
};

const mysql = require("mysql2");
const dbConfig = require("./db.config.js");

// createPool manages multiple connections automatically and reconnects if one drops
const pool = mysql.createPool({
    host: dbConfig.HOST,
    user: dbConfig.USER,
    password: dbConfig.PASSWORD,
    database: dbConfig.DB,
    connectionLimit: 10,
    waitForConnections: true,
    dateStrings: true
});

// Test the pool on startup
pool.query("SELECT 1", function (error) {
    if (error) {
        console.log("Database connection failed: ", error.message);
    } else {
        console.log("Successfully connected to the database.");
    }
});

module.exports = pool;

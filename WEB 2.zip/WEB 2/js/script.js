// --- 1. נתונים ומערכות ---
let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
let allUsers = JSON.parse(localStorage.getItem('allUsers')) || [];
let events = JSON.parse(localStorage.getItem('events')) || [];
let currentActiveEventId = null;

// --- 2. האזנה לטעינת הדף (EventListener 1) ---
document.addEventListener('DOMContentLoaded', () => {
    updateNavbar();
    const path = window.location.pathname;

    if (path.includes('dashboard.html')) {
        renderDashboard();
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('action') === 'create') {
            showDashboardSub('create-event-section');
        }
    }
    
    if (path.includes('profile.html')) renderProfile();
// ניהול כפתורי הפעולה (דף הבית ודף אודות)
    const ctaButtons = [document.getElementById('heroCTA'), document.getElementById('aboutCTA')];
    ctaButtons.forEach(btn => {
        if (btn) {
            if (currentUser) {
                btn.innerText = 'צור אירוע חדש';
                btn.href = 'dashboard.html?action=create';
            } else {
                btn.innerText = 'התחילו עכשיו';
                btn.href = 'auth.html';
            }
        }
    });

    // הגבלת תאריך עתידי
    const dateInput = document.getElementById('eventDate');
    if (dateInput) dateInput.min = new Date().toISOString().split('T')[0];

    setupFormListeners();
});

function updateNavbar() {
    const nav = document.getElementById('main-nav');
    if (!nav) return;
    const links = [`<li class="nav-item"><a class="nav-link" href="index.html">בית</a></li>`];
    links.push(`<li class="nav-item"><a class="nav-link" href="about.html">אודות</a></li>`);
    
    if (currentUser) {
        links.push(`<li class="nav-item"><a class="nav-link" href="dashboard.html">לוח בקרה</a></li>`);
        links.push(`<li class="nav-item"><a class="nav-link" href="profile.html">פרופיל</a></li>`);
        links.push(`<li class="nav-item"><a class="nav-link text-danger fw-bold" href="#" onclick="logout()">התנתק</a></li>`);
    } else {
        links.push(`<li class="nav-item"><a class="nav-link fw-bold text-primary" href="auth.html">התחברות</a></li>`);
    }
    nav.innerHTML = links.join('');

    // תפריט המבורגר למובייל
    const headerContainer = document.querySelector('header .container');
    if (headerContainer && !document.getElementById('mobileMenuBtn')) {
        const mobileBtn = document.createElement('button');
        mobileBtn.id = 'mobileMenuBtn';
        mobileBtn.className = 'mobile-menu-btn d-md-none';
        mobileBtn.innerHTML = '☰'; 
        
        headerContainer.insertBefore(mobileBtn, headerContainer.querySelector('nav'));

        mobileBtn.addEventListener('click', () => {
            nav.classList.toggle('show-mobile');
        });
    }
}

// --- 3. ולידציות וטפסים (EventListener 2) ---
function setupFormListeners() {
    const signupForm = document.getElementById('signupForm');
    if (signupForm) signupForm.addEventListener('submit', handleSignup);

    const loginForm = document.getElementById('loginForm');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);

    const eventForm = document.getElementById('eventForm');
    if (eventForm) eventForm.addEventListener('submit', handleCreateEvent);
}

function handleSignup(e) {
    e.preventDefault();
    const email = document.getElementById('regEmail').value;
    const phone = document.getElementById('regPhone').value;
    const pass = document.getElementById('regPass').value;
    const name = document.getElementById('regName').value;

    if (name.trim().length < 2) return alert("שם חייב להכיל לפחות 2 תווים");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return alert("כתובת אימייל לא תקינה");
    if (!/^05\d{8}$/.test(phone)) return alert("טלפון חייב להיות 10 ספרות ולהתחיל ב-05");
    if (pass.length < 8) return alert("סיסמה חייבת להיות לפחות 8 תווים");
    if (allUsers.find(u => u.email === email)) return alert("משתמש רשום");

    currentUser = { name, email, phone, pass };
    allUsers.push(currentUser);
    localStorage.setItem('allUsers', JSON.stringify(allUsers));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    window.location.href = 'dashboard.html';
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('logEmail').value;
    const pass = document.getElementById('logPass').value;
    const user = allUsers.find(u => u.email === email);
    
    if (!user) return alert("אינך רשום למערכת נא הירשם");
    if (user.pass !== pass) return alert("סיסמה שגויה");

    currentUser = user;
    localStorage.setItem('currentUser', JSON.stringify(user));
    window.location.href = 'dashboard.html';
}

function handleCreateEvent(e) {
    e.preventDefault();
    const emails = document.getElementById('invites').value.split(',').map(m => m.trim()).filter(m => m);
    const newEv = {
        id: Date.now().toString(), creator: currentUser.email,
        name: document.getElementById('eventName').value, date: document.getElementById('eventDate').value,
        loc: document.getElementById('eventLocation').value || 'לא צוין',
        desc: document.getElementById('eventDesc').value,
        tasks: [], comments: [], participants: [currentUser.email, ...emails],
        rsvps: { [currentUser.email]: 'confirmed' }
    };
    events.push(newEv);
    localStorage.setItem('events', JSON.stringify(events));
    window.location.replace('dashboard.html'); // תיקון חזרה ללוח בקרה נקי לאחר יצירה
}

// --- 4. לוגיקת דשבורד ---
function renderDashboard() {
    const list = document.getElementById('dynamicEventList');
    if (!list) return;
    const myEvents = events.filter(e => e.participants.includes(currentUser.email));
    document.getElementById('eventCount').innerText = myEvents.length;

    list.innerHTML = myEvents.map(e => {
        const isManager = e.creator === currentUser.email;
        const confirmedCount = Object.values(e.rsvps).filter(v => v === 'confirmed').length;
        return `
        <div class="card p-3 mb-3 border-0 shadow-sm d-flex flex-row justify-content-between align-items-center">
            <div>
                <h5 class="text-primary mb-1 fw-bold">${e.name}</h5>
                <small>📅 ${e.date} | 📍 ${e.loc}</small><br>
                <small class="text-muted">👥 ${e.participants.length} מוזמנים | ✅ ${confirmedCount} אישרו</small>
            </div>
            <div>
                <button class="btn btn-sm btn-outline-dark mx-1" onclick="viewEventDetails('${e.id}')">${isManager ? 'ניהול וציוות' : 'פרטי אירוע'}</button>
                ${isManager ? `<button class="btn btn-sm btn-outline-danger" onclick="deleteEvent('${e.id}')">מחק</button>` : ''}
            </div>
        </div>`;
    }).join('') || '<p class="text-center mt-3">אין אירועים.</p>';
}

window.viewEventDetails = function(id) {
    const ev = events.find(e => e.id === id);
    if (!ev) return;
    currentActiveEventId = id;
    
    document.getElementById('dashboard-section').style.display = 'none';
    document.getElementById('event-details-section').style.display = 'block';

    document.getElementById('detName').innerText = ev.name;
    document.getElementById('detMeta').innerText = `📅 ${ev.date} | 📍 ${ev.loc}`;
    document.getElementById('detDesc').innerText = ev.desc;

    const isManager = ev.creator === currentUser.email;
    document.getElementById('inviteArea').style.display = isManager ? 'flex' : 'none';

    const rsvpArea = document.getElementById('rsvpControlsArea');
    if (isManager) {
        rsvpArea.innerHTML = `<span class="badge bg-primary fs-6">מנהל/ת</span>`;
    } else {
        const myStatus = ev.rsvps[currentUser.email] || 'pending';
        rsvpArea.innerHTML = `
            <div class="btn-group">
                <button class="btn btn-sm ${myStatus === 'confirmed' ? 'btn-success' : 'btn-outline-success'}" onclick="setRSVP('confirmed')">מגיע/ה</button>
                <button class="btn btn-sm ${myStatus === 'declined' ? 'btn-danger' : 'btn-outline-danger'}" onclick="setRSVP('declined')">לא יכול/ה</button>
            </div>`;
    }

    const controls = document.getElementById('taskManagerControls');
    if (isManager) {
        let options = `<option value="">-- פנוי --</option>` + ev.participants.map(email => {
            const u = allUsers.find(user => user.email === email);
            return `<option value="${email}">${u ? u.name : email}</option>`;
        }).join('');
        controls.innerHTML = `<div class="input-group input-group-sm mb-2"><input type="text" id="taskInput" class="form-control" placeholder="משימה..."><select id="personSelect" class="form-select">${options}</select><button class="btn btn-dark" onclick="addTask()">צור</button></div>`;
    } else {
        controls.innerHTML = `<p class="small text-muted mb-0">בחרו משימה פנויה מהרשימה</p>`;
    }

    renderGuestList(ev); renderTasks(); renderComments(ev);
};

window.addTask = function() {
    const name = document.getElementById('taskInput').value;
    const selectedEmail = document.getElementById('personSelect').value;
    if (!name) return;
    const ev = events.find(e => e.id === currentActiveEventId);
    ev.tasks.push({ name, email: selectedEmail, assignedByManager: selectedEmail !== "" });
    localStorage.setItem('events', JSON.stringify(events));
    renderTasks();
    document.getElementById('taskInput').value = "";
};

window.changeTaskAssignee = function(index, newEmail) {
    const ev = events.find(e => e.id === currentActiveEventId);
    ev.tasks[index].email = newEmail;
    ev.tasks[index].assignedByManager = newEmail !== "";
    localStorage.setItem('events', JSON.stringify(events));
    renderTasks();
};

function renderTasks() {
    const tbody = document.getElementById('taskTableBody');
    const ev = events.find(e => e.id === currentActiveEventId);
    const isManager = ev.creator === currentUser.email;

    tbody.innerHTML = ev.tasks.map((t, i) => {
        let assigneeDisplay = '';
        if (isManager) {
            let options = `<option value="">-- פנוי --</option>` + ev.participants.map(email => {
                const u = allUsers.find(user => user.email === email);
                return `<option value="${email}" ${t.email === email ? 'selected' : ''}>${u ? u.name : email}</option>`;
            }).join('');
            assigneeDisplay = `<select class="form-select form-select-sm" onchange="changeTaskAssignee(${i}, this.value)">${options}</select>`;
        } else {
            const u = allUsers.find(user => user.email === t.email);
            assigneeDisplay = t.email ? (u ? u.name : t.email) : 'פנוי';
        }

        let button = '';
        if (!t.email && !isManager) button = `<button class="btn btn-xs btn-success py-0" onclick="volunteerTask(${i})">אני אביא</button>`;
        else if (isManager || (!t.assignedByManager && t.email === currentUser.email)) button = `<button class="btn btn-xs btn-danger py-0" onclick="cancelTask(${i})">בטל</button>`;
        
        return `<tr><td>${t.name}</td><td>${assigneeDisplay}</td><td>${button}</td></tr>`;
    }).join('');
}

window.volunteerTask = function(i) {
    const ev = events.find(e => e.id === currentActiveEventId);
    ev.tasks[i].email = currentUser.email;
    ev.tasks[i].assignedByManager = false;
    localStorage.setItem('events', JSON.stringify(events));
    renderTasks();
};

window.cancelTask = function(i) {
    const ev = events.find(e => e.id === currentActiveEventId);
    const isManager = ev.creator === currentUser.email;
    if (isManager && ev.tasks[i].email === "") ev.tasks.splice(i, 1);
    else ev.tasks[i].email = "";
    localStorage.setItem('events', JSON.stringify(events));
    renderTasks();
};

// --- 5. שיח קבוצתי ---
window.postComment = function() {
    const input = document.getElementById('commentInput');
    if (!input.value) return;
    const ev = events.find(e => e.id === currentActiveEventId);
    ev.comments.push({ user: currentUser.name, text: input.value });
    localStorage.setItem('events', JSON.stringify(events));
    renderComments(ev);
    input.value = '';
};

function renderComments(ev) {
    const area = document.getElementById('commentsArea');
    if(!area) return;
    area.innerHTML = ev.comments.map(c => `<div class="p-2 mb-1 bg-white rounded shadow-sm small"><strong>${c.user}:</strong> ${c.text}</div>`).join('');
    area.scrollTop = area.scrollHeight;
}

// --- 6. פרופיל ---
function renderProfile() {
    if (!currentUser) return;
    const nameEl = document.getElementById('profName');
    const emailEl = document.getElementById('profEmail');
    if (nameEl) nameEl.innerText = currentUser.name;
    if (emailEl) emailEl.innerText = currentUser.email;

    const list = document.getElementById('userHistoryList');
    if (list) {
        const myEvents = events.filter(e => e.participants.includes(currentUser.email));
        list.innerHTML = myEvents.map(e => `<li class="mb-2 p-2 bg-light rounded shadow-sm">${e.name} (${e.date})</li>`).join('') || 'טרם השתתפת באירועים.';
    }
}

window.setRSVP = function(status) {
    const ev = events.find(e => e.id === currentActiveEventId);
    ev.rsvps[currentUser.email] = status;
    localStorage.setItem('events', JSON.stringify(events));
    viewEventDetails(currentActiveEventId);
};

window.deleteEvent = function(id) {
    if (confirm('מחק אירוע?')) {
        events = events.filter(e => e.id !== id);
        localStorage.setItem('events', JSON.stringify(events));
        renderDashboard();
    }
};

window.inviteMoreGuests = function() {
    const email = document.getElementById('newGuestEmail').value.trim();
    if (!email) return alert("נא להזין כתובת אימייל");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return alert("כתובת אימייל לא תקינה");
    const ev = events.find(e => e.id === currentActiveEventId);
    if (!ev.participants.includes(email)) {
        ev.participants.push(email);
        localStorage.setItem('events', JSON.stringify(events));
        renderGuestList(ev);
        viewEventDetails(currentActiveEventId);
    }
    document.getElementById('newGuestEmail').value = '';
};

function renderGuestList(ev) {
    const list = document.getElementById('guestListGroup');
    list.innerHTML = ev.participants.map(email => {
        const u = allUsers.find(user => user.email === email);
        const name = u ? u.name : email;
        const isManager = email === ev.creator;
        const status = ev.rsvps[email] || 'pending';
        let badge = isManager ? '<span class="badge bg-primary">מנהל/ת</span>' : '';
        if (!isManager && ev.creator === currentUser.email) {
            if (status === 'confirmed') badge = '<span class="badge bg-success">מאשר</span>';
            else if (status === 'declined') badge = '<span class="badge bg-danger">לא מגיע</span>';
            else badge = '<span class="badge bg-light text-dark border">טרם השיב</span>';
        }
        return `<li class="list-group-item d-flex justify-content-between align-items-center py-1 border-0">${name} ${badge}</li>`;
    }).join('');
}

function logout() { localStorage.removeItem('currentUser'); window.location.href = 'index.html'; }

// --- פונקציות ניווט ---
function toggleAuth() {
    const l = document.getElementById('loginBox');
    const s = document.getElementById('signupBox');
    if (l.style.display === 'none') {
        l.style.display = 'block';
        s.style.display = 'none';
    } else {
        l.style.display = 'none';
        s.style.display = 'block';
    }
}

function showDashboardSub(id) {
    // מנקה את ה-URL מפרמטרים כדי שלא יתקע על מצב create
    window.history.replaceState({}, document.title, window.location.pathname);
    
    ['dashboard-section', 'create-event-section', 'event-details-section'].forEach(s => {
        document.getElementById(s).style.display = 'none';
    });
    document.getElementById(id).style.display = 'block';
    if (id === 'dashboard-section') renderDashboard();
}